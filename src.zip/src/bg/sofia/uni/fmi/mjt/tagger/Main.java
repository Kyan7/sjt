package bg.sofia.uni.fmi.mjt.tagger;

import java.io.*;
import java.util.*;

public class Main {
    static final String OPENING_COUNTRY_TAG_FRAG_1 = "<city country=\"";
    static final String OPENING_COUNTRY_TAG_FRAG_2 = "\">";
    static final String CLOSING_COUNTRY_TAG = "</city>";

    public static void main(String[] args) throws IOException {

    }
}
